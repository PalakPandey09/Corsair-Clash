using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;

public class HealthBoundaryTest
{
   
    
    // A Test behaves as an ordinary method
    [Test]
    public void Health_For_Player_Ship()
    {
        var player = new GameObject().AddComponent<player_health>();

        Assert.AreEqual(150f, player.player_ship_health);
    }

    [Test]
    public void Health_For_Player_Unit()
    {
        var player = new GameObject().AddComponent<player_health>();

        Assert.AreEqual(10f, player.player_unit_1_health);
    }

    [Test]
    public void Health_For_Enemy_Ship()
    {
        var enemy = new GameObject().AddComponent<enemy_health>();

        Assert.AreEqual(150f, enemy.enemy_ship_health);
    }
  
    [Test]
    public void Health_For_Enemy_Unit()
    {
        var enemy = new GameObject().AddComponent<enemy_health>();

        Assert.AreEqual(10f, enemy.enemy_unit_1_health);
    }
}
