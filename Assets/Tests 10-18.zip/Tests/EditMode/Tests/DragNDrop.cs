using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
/*
public class DragNDropTest
{
 
    
    // A Test behaves as an ordinary method
    [Test]
    public void ValidDrag()
    {
        actionEvent lowerBound = new actionEvent();
        lowerBound.

        Assert.IsTrue(lowerBound.getUpdate)
    }
}
*/