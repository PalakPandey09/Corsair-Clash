using NUnit.Framework;

namespace Tests{
public class DirectionTests
{
    // A Test behaves as an ordinary method
    [Test]
    public void North()
    {
        //Assert.AreEqual(expected: new Vector3(x:0, y:1, z:0), actual: Direction.North.Vector);
    }

}
}