using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipMovement : MonoBehaviour
{
    Rigidbody2D ship;

    float move;
    float moveSpeed = 10f;
    Vector2 currentVeloctiy;

    bool isTrigger = false;

    // Start is called before the first frame update
    void Start()
    {
        ship = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        move = Input.GetAxisRaw("Horizontal");

        currentVeloctiy = new Vector2(move, 0f) * moveSpeed;

        if(Input.GetKeyDown(KeyCode.Space))
        {
            if(isTrigger == true)
            {
                Debug.Log("New Map");
            }
        }

    }

    void FixedUpdate()
    {
        MovePlayer();
    }

    void MovePlayer()
    {
        if(move != 0)
        {
            ship.velocity = currentVeloctiy;
        }
        else
        {
            currentVeloctiy = new Vector2(0f, 0f);
            ship.velocity = currentVeloctiy;
        }
    }

    //private void OnCollisionEnter2D(Collision2D collision)
    //{
    //    Debug.Log("Collided with an island");
    //}

    //private void OnTriggerEnter2D(Collider2D collision)
    //{
    //    if(collision.gameObject.tag == "Island")
    //    {
    //        Debug.Log("Trigger battle");
    //    }
    //}

}
